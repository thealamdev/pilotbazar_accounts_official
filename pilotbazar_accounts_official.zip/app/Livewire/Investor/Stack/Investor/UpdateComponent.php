<?php

namespace App\Livewire\Investor\Stack\Investor;

use Livewire\Component;

class UpdateComponent extends Component
{
    public function render()
    {
        return view('livewire.investor.stack.investor.update-component');
    }
}
