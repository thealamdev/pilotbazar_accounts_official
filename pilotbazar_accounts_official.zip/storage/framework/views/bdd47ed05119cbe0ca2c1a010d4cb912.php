<div class="mt-7">
    <div class="row border border-slate-400 p-3">
        <!-- Basic Infos part Start !-->
        <div class="col-lg-5 pe-3" style="border-right:1px solid #c2c7ce">
            <?php echo $__env->make('livewire.vehicle-management.show.vehicle.partials.basic-infos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- Basic Infos part End !-->

        <div class="col-lg-7 ps-3">
            <!-- Media Costing Part Start !-->
            <?php echo $__env->make('livewire.vehicle-management.show.vehicle.partials.media-costing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--Media Costing Part End !-->

            <!-- Maintenance Costing Part Start !-->
            <?php echo $__env->make('livewire.vehicle-management.show.vehicle.partials.maintenance-costing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--Maintenance Costing Part End !-->

            <!-- Service Costing Part Start !-->
            <?php echo $__env->make('livewire.vehicle-management.show.vehicle.partials.service-costing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--Service Costing Part End !-->

            <!-- Parts Costing Part Start !-->
            <?php echo $__env->make('livewire.vehicle-management.show.vehicle.partials.parts-costing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Parts Costing Part End !-->

            <!-- Total Costing Part Start !-->
            <hr class="hr">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between pb-1">
                        <p style="width:49%">Total Costing</p>
                        <p style="width:21%">=</p>
                        <p style="width:30%;text-align:end"><?php echo e($response?->mediaCosting?->sum('amount') + $response?->maintenanceCosting?->sum('amount') + $response?->serviceCosting?->sum('amount') + $response?->partsCosting?->sum('amount')); ?> tk</p>
                    </div>
                </div>
            </div>
            <!-- Total Costing Part End !-->
        </div>

    </div>
</div>
<?php /**PATH C:\laragon\www\pilotbazar_accounts_official\resources\views/livewire/vehicle-management/show/vehicle/show-vehicle-component.blade.php ENDPATH**/ ?>