<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo e(config('app.name')); ?> | <?php echo e($title ?? 'Home'); ?></title>
        <meta name="description" content="Pilot Bazar Accounts Application" />

        <!-- Favicon -->
        <link rel="shortcut icon" href="favicon.ico">
        <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

        <!-- Daterangepicker CSS -->
        <link href="<?php echo e(asset('assets/css/daterangepicker.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Data Table CSS -->
        <link href="<?php echo e(asset('assets/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Boostrap CSS -->
        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Font awesome CSS -->
        <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Dripicons CSS -->
        <link href="<?php echo e(asset('assets/css/dripicons.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Animate CSS !-->
        <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Line Awesome CSS !-->
        <link href="<?php echo e(asset('assets/css/line-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Prism CSS !-->
        <link href="<?php echo e(asset('assets/css/prism.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Simple sidebar CSS !-->
        <link href="<?php echo e(asset('assets/css/simplebar.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Owl carousel CSS !-->
        <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Owl theme default CSS !-->
        <link href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Font awesome cdn !-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <!-- Toastr css cdn !-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css" />

        <!-- CSS -->
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
        <?php echo $__env->yieldPushContent('css'); ?>
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>

    <body>

        <div class="hk-wrapper" data-layout="vertical" data-layout-style="default" data-menu="light" data-footer="simple">
            <?php echo $__env->make('livewire.hooks.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('livewire.hooks.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Main Content -->
            <div class="hk-pg-wrapper">
                <div class="container-xxl">
                    <?php echo e($slot); ?>

                </div>
                <?php echo $__env->make('livewire.hooks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /Main Content -->
        </div>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

        <!-- jQuery -->
        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

        <!-- Bootstrap Core JS -->
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

        <!-- FeatherIcons JS -->
        <script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>

        <!-- Fancy Dropdown JS -->
        <script src="<?php echo e(asset('assets/js/dropdown-bootstrap-extended.js')); ?>"></script>

        <!-- Simplebar JS -->
        <script src="<?php echo e(asset('assets/js/simplebar.min.js')); ?>"></script>

        <!-- Data Table JS -->
        <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/dataTables.bootstrap5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/dataTables.select.min.js')); ?>"></script>

        <!-- Daterangepicker JS -->
        <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/daterangepicker.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/daterangepicker-data.js')); ?>"></script>

        <!-- Amcharts Maps JS -->
        <script src="<?php echo e(asset('assets/js/core.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/maps.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/worldHigh.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/worldLow.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/animated.js')); ?>"></script>

        <!-- Apex JS -->
        <script src="<?php echo e(asset('assets/js/apexcharts.min.js')); ?>"></script>

        <!-- Init JS -->
        <script src="<?php echo e(asset('assets/js/init.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/chips-init.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/dashboard-data.js')); ?>"></script>

        <!-- Toastr js cdn !-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>

        <!-- Toaster noticiction init !-->
        <script>
            $(document).ready(function() {
                toastr.options = {
                    "progressBar": true,
                    "positionClass": "toast-top-right",
                }
            });

            window.addEventListener('success', event => {
                toastr.success(event.detail[0].message);
            });
        </script>
        <?php echo $__env->yieldPushContent('js'); ?>

    </body>

</html>
<?php /**PATH C:\laragon\www\pilotbazar_accounts_official\resources\views/layouts/app.blade.php ENDPATH**/ ?>