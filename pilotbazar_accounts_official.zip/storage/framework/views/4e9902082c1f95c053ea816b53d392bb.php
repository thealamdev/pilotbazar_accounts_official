<table class="table nowrap w-100 mb-5">
    <thead>
        <tr>
            <th>Name</th>
            <th>Model</th>
            <th>Model Year</th>
            <th>Color</th>
            <th>Purchase Price</th>
            <th>Total Price</th>
            <th class="text-center">Status</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>

    <tbody>
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <div class="text-high-em"><?php echo e($each?->name); ?></div>
                </td>
                <td>
                    <div class="text-high-em"><?php echo e($each?->models?->name); ?></div>
                </td>
                <td>
                    <div class="text-high-em"><?php echo e($each?->model_year?->name); ?></div>
                </td>
                <td>
                    <div class="text-high-em"><?php echo e($each?->color?->name); ?></div>
                </td>
                <td>
                    <div class="text-high-em"><?php echo e($each?->purchase_price); ?></div>
                </td>
                <td>
                    <div class="text-high-em"><?php echo e($each?->total_cost); ?></div>
                </td>
                <td>
                    <div class="fs-8 ms-3">
                        <?php echo e($each?->status == 1 ? 'Active' : 'Inactive'); ?>

                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <a title="Edit" class="btn btn-icon btn-flush-dark btn-rounded flush-soft-hover" href="<?php echo e(route('admin.version1.vehicle-management.vehicle.module.color.update', ['color' => $each->id])); ?>">
                            <span class="icon">
                                <span class="feather-icon">
                                    <i class="fa-solid fa-pen" style="color:gray"></i>
                                </span>
                            </span>
                        </a>
                        <button title="Trash" type="button" wire:click="delete(<?php echo e($each->id); ?>)" class="btn btn-icon btn-flush-dark btn-rounded flush-soft-hover del-button" wire:confirm="Are you sure you want to delete this post?">
                            <span class="icon">
                                <span class="feather-icon">
                                    <i class="fa-solid fa-eraser" style="color:gray"></i>
                                </span>
                            </span>
                        </button>
                        <a title="Add Costing" href="<?php echo e(route('admin.version1.vehicle-management.vehicle.costing.create', ['vehicle' => $each?->id])); ?>" class="btn btn-icon btn-flush-dark btn-rounded flush-soft-hover">
                            <span class="icon">
                                <span class="feather-icon">
                                    <i class="fa-solid fa-coins" style="color:gray"></i>
                                </span>
                            </span>
                        </a>
                        <a title="Buy Payment" href="<?php echo e(route('admin.version1.vehicle-management.vehicle.buy-payment.create', ['vehicle' => $each?->id])); ?>" class="btn btn-icon btn-flush-dark btn-rounded flush-soft-hover">
                            <span class="icon">
                                <span class="feather-icon">
                                    <i class="fa-solid fa-money-bill-wave"></i>
                                </span>
                            </span>
                        </a>
                        <a title="Show" href="<?php echo e(route('admin.version1.vehicle-management.vehicle.show', ['vehicle' => $each?->id])); ?>" class="btn btn-icon btn-flush-dark btn-rounded flush-soft-hover">
                            <span class="icon">
                                <span class="feather-icon">
                                    <i class="fa-solid fa-arrow-right" style="color:gray"></i>
                                </span>
                            </span>
                        </a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <td class="text-center text-danger fs-3" colspan="9">No data found !!</td>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </tbody>

    <tfoot>
        <tr>
            <td>Name</td>
            <td>Model</td>
            <td>Model Year</td>
            <td>Color</td>
            <td>Purchase Price</td>
            <td>Total Price</td>
            <td class="text-center">Status</td>
            <td class="text-center">Action</td>
        </tr>
    </tfoot>
</table>
<?php /**PATH C:\laragon\www\pilotbazar_accounts_official\resources\views/livewire/vehicle-management/table/vehicle/partials/table.blade.php ENDPATH**/ ?>