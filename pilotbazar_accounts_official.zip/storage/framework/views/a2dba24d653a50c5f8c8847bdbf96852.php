<!-- Page Footer -->
<div class="hk-footer">
    <footer class="container-xxl footer">
        <div class="row">
            <div class="col-xl-8">
                <p class="footer-text"><span class="copy-text">Pilot Bazar © 2024 All rights reserved.</span> <a href="#" class="" target="_blank">Privacy Policy</a><span class="footer-link-sep">|</span><a href="#" class="" target="_blank">T&C</a><span class="footer-link-sep">|</span><a href="#" class="" target="_blank">System Status</a></p>
            </div>
            <div class="col-xl-4">
                <a href="#" class="footer-extr-link link-default"><span class="feather-icon"><i data-feather="external-link"></i></span><u>Send feedback to our help forum</u></a>
            </div>
        </div>
    </footer>
</div>
<!-- / Page Footer --><?php /**PATH C:\laragon\www\pilotbazar_accounts_official\resources\views/livewire/hooks/footer.blade.php ENDPATH**/ ?>